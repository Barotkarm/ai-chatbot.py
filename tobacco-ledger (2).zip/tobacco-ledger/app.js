const STORAGE_KEY = 'tobacco_ledger_data';

const defaultData = () => ({
  products: [],
  bills: [],
  purchases: [],
  income: [],
  expenses: []
});

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : defaultData();
  } catch {
    return defaultData();
  }
}

function save(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function fmt(n) {
  return '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    + ' ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

function todayStr() {
  return new Date().toDateString();
}

function toast(msg, type = 'success') {
  const box = document.getElementById('toastBox');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  el.innerHTML = `<span>${icons[type] || '✅'}</span><span>${msg}</span>`;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function setGreeting() {
  const h = new Date().getHours();
  let en, hi;
  if (h < 12) { en = 'Good Morning'; hi = 'सुप्रभात'; }
  else if (h < 17) { en = 'Good Afternoon'; hi = 'नमस्कार'; }
  else { en = 'Good Evening'; hi = 'शुभ संध्या'; }
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const d = new Date();
  document.getElementById('greeting').textContent =
    `${en} / ${hi} · ${days[d.getDay()]} ${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
}

let data = load();
setGreeting();

// --- Tabs ---
function switchTab(tabId) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  const tab = document.querySelector(`.tab[data-tab="${tabId}"]`);
  const panel = document.getElementById(tabId);
  if (tab) tab.classList.add('active');
  if (panel) panel.classList.add('active');
}

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => switchTab(tab.dataset.tab));
});

document.querySelectorAll('.quick-btn').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.go));
});

// --- Products ---
document.getElementById('addProductForm').addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('productName').value.trim();
  const buyPrice = parseFloat(document.getElementById('productBuyPrice').value);
  const sellPrice = parseFloat(document.getElementById('productSellPrice').value);
  const stock = parseInt(document.getElementById('productStock').value) || 0;

  data.products.push({ id: uid(), name, buyPrice, sellPrice, stock });
  save(data);
  e.target.reset();
  renderAll();
  toast('Product added! / सामान जोड़ा गया — ' + name, 'success');
});

function deleteProduct(id) {
  if (!confirm('Delete this product? / यह सामान हटाएं?')) return;
  data.products = data.products.filter(p => p.id !== id);
  save(data);
  renderAll();
}

// --- Sell ---
const sellProduct = document.getElementById('sellProduct');
const sellQty = document.getElementById('sellQty');
const sellPrice = document.getElementById('sellPrice');

function updateBillPreview() {
  const q = parseFloat(sellQty.value) || 0;
  const p = parseFloat(sellPrice.value) || 0;
  document.getElementById('billPreview').textContent = fmt(q * p);
}

sellProduct.addEventListener('change', () => {
  const prod = data.products.find(p => p.id === sellProduct.value);
  if (prod) {
    sellPrice.value = prod.sellPrice;
    updateBillPreview();
  }
});

sellQty.addEventListener('input', updateBillPreview);
sellPrice.addEventListener('input', updateBillPreview);

document.getElementById('sellForm').addEventListener('submit', e => {
  e.preventDefault();
  const productId = sellProduct.value;
  const prod = data.products.find(p => p.id === productId);
  if (!prod) return;

  const qty = parseInt(sellQty.value);
  const rate = parseFloat(sellPrice.value);
  const total = qty * rate;

  if (qty > prod.stock) {
    toast('Not enough stock! / स्टॉक कम है — Available: ' + prod.stock, 'error');
    return;
  }

  prod.stock -= qty;

  const bill = {
    id: uid(),
    date: new Date().toISOString(),
    customer: document.getElementById('customerName').value.trim() || 'Walk-in / साधारण',
    productId,
    productName: prod.name,
    qty,
    rate,
    total
  };

  data.bills.unshift(bill);
  data.income.unshift({
    id: uid(),
    date: bill.date,
    note: 'Bill: ' + prod.name + ' x' + qty + (bill.customer !== 'Walk-in / साधारण' ? ' (' + bill.customer + ')' : ''),
    amount: total,
    ref: bill.id
  });

  save(data);
  e.target.reset();
  document.getElementById('billPreview').textContent = fmt(0);
  renderAll();
  toast('Bill saved! / बिल सेव — ' + fmt(total), 'success');
});

function deleteBill(id) {
  if (!confirm('Delete this bill? Stock will be restored. / बिल हटाएं?')) return;
  const bill = data.bills.find(b => b.id === id);
  if (bill) {
    const prod = data.products.find(p => p.id === bill.productId);
    if (prod) prod.stock += bill.qty;
    data.income = data.income.filter(i => i.ref !== id);
  }
  data.bills = data.bills.filter(b => b.id !== id);
  save(data);
  renderAll();
}

// --- Buy ---
const buyProduct = document.getElementById('buyProduct');
const buyQty = document.getElementById('buyQty');
const buyPrice = document.getElementById('buyPrice');

function updateBuyPreview() {
  const q = parseFloat(buyQty.value) || 0;
  const p = parseFloat(buyPrice.value) || 0;
  document.getElementById('buyPreview').textContent = fmt(q * p);
}

buyProduct.addEventListener('change', () => {
  const prod = data.products.find(p => p.id === buyProduct.value);
  if (prod) {
    buyPrice.value = prod.buyPrice;
    updateBuyPreview();
  }
});

buyQty.addEventListener('input', updateBuyPreview);
buyPrice.addEventListener('input', updateBuyPreview);

document.getElementById('buyForm').addEventListener('submit', e => {
  e.preventDefault();
  const productId = buyProduct.value;
  const prod = data.products.find(p => p.id === productId);
  if (!prod) return;

  const qty = parseInt(buyQty.value);
  const rate = parseFloat(buyPrice.value);
  const total = qty * rate;

  prod.stock += qty;
  prod.buyPrice = rate;

  const purchase = {
    id: uid(),
    date: new Date().toISOString(),
    productId,
    productName: prod.name,
    qty,
    rate,
    total
  };

  data.purchases.unshift(purchase);
  data.expenses.unshift({
    id: uid(),
    date: purchase.date,
    note: 'Purchase: ' + prod.name + ' x' + qty,
    amount: total,
    ref: purchase.id
  });

  save(data);
  e.target.reset();
  document.getElementById('buyPreview').textContent = fmt(0);
  renderAll();
  toast('Purchase recorded! / खरीद दर्ज — ' + fmt(total), 'success');
});

function deletePurchase(id) {
  if (!confirm('Delete this purchase? Stock will be reduced. / खरीद हटाएं?')) return;
  const purchase = data.purchases.find(p => p.id === id);
  if (purchase) {
    const prod = data.products.find(p => p.id === purchase.productId);
    if (prod) prod.stock = Math.max(0, prod.stock - purchase.qty);
    data.expenses = data.expenses.filter(e => e.ref !== id);
  }
  data.purchases = data.purchases.filter(p => p.id !== id);
  save(data);
  renderAll();
}

// --- Money ---
document.getElementById('incomeForm').addEventListener('submit', e => {
  e.preventDefault();
  data.income.unshift({
    id: uid(),
    date: new Date().toISOString(),
    note: document.getElementById('incomeNote').value.trim(),
    amount: parseFloat(document.getElementById('incomeAmount').value)
  });
  save(data);
  e.target.reset();
  renderAll();
});

document.getElementById('expenseForm').addEventListener('submit', e => {
  e.preventDefault();
  data.expenses.unshift({
    id: uid(),
    date: new Date().toISOString(),
    note: document.getElementById('expenseNote').value.trim(),
    amount: parseFloat(document.getElementById('expenseAmount').value)
  });
  save(data);
  e.target.reset();
  renderAll();
});

function deleteMoney(type, id) {
  if (!confirm('Delete this entry? / हटाएं?')) return;
  if (type === 'income') data.income = data.income.filter(i => i.id !== id);
  else data.expenses = data.expenses.filter(e => e.id !== id);
  save(data);
  renderAll();
}

// --- Backup ---
document.getElementById('exportBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'tobacco-ledger-backup-' + new Date().toISOString().slice(0, 10) + '.json';
  a.click();
  toast('Backup downloaded! / बैकअप डाउनलोड', 'info');
});

document.getElementById('importFile').addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      if (!imported.products) throw new Error('Invalid file');
      if (confirm('Replace all data with backup? / सारा डेटा बदलें?')) {
        data = imported;
        save(data);
        renderAll();
        toast('Backup restored! / बैकअप लोड हो गया', 'success');
      }
    } catch {
      toast('Invalid backup file / गलत फाइल', 'error');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

// --- Render ---
function renderDashboard() {
  const totalIncome = data.income.reduce((s, i) => s + i.amount, 0);
  const totalExpense = data.expenses.reduce((s, e) => s + e.amount, 0);
  const todaySales = data.bills
    .filter(b => new Date(b.date).toDateString() === todayStr())
    .reduce((s, b) => s + b.total, 0);

  const profit = totalIncome - totalExpense;
  const profitEl = document.getElementById('totalProfit');
  document.getElementById('totalIncome').textContent = fmt(totalIncome);
  document.getElementById('totalExpense').textContent = fmt(totalExpense);
  profitEl.textContent = fmt(profit);
  profitEl.classList.remove('positive', 'negative');
  if (profit > 0) profitEl.classList.add('positive');
  else if (profit < 0) profitEl.classList.add('negative');
  document.getElementById('todaySales').textContent = fmt(todaySales);
  document.getElementById('productCount').textContent = data.products.length;

  const recent = document.getElementById('recentBills');
  const latest = data.bills.slice(0, 5);
  recent.innerHTML = latest.length
    ? latest.map(b => `
      <div class="list-item">
        <div class="item-avatar sell">🧾</div>
        <div class="info">
          <div class="title">${b.productName} × ${b.qty}</div>
          <div class="meta">${b.customer} · ${fmtDate(b.date)}</div>
        </div>
        <div class="right">
          <div class="amount income">${fmt(b.total)}</div>
        </div>
      </div>`).join('')
    : '<div class="empty"><span class="empty-icon">🧾</span>No bills yet<br>अभी कोई बिल नहीं</div>';
}

function renderProducts() {
  const list = document.getElementById('productList');
  list.innerHTML = data.products.length
    ? data.products.map(p => `
      <div class="list-item">
        <div class="item-avatar product">📦</div>
        <div class="info">
          <div class="title">${p.name}</div>
          <div class="price-tags">
            <span class="price-tag">Buy ${fmt(p.buyPrice)}</span>
            <span class="price-tag">Sell ${fmt(p.sellPrice)}</span>
          </div>
          <span class="stock-badge ${p.stock <= 5 ? 'low' : ''}">Stock / स्टॉक: ${p.stock}</span>
        </div>
        <div class="right">
          <button class="delete-btn" onclick="deleteProduct('${p.id}')">Delete</button>
        </div>
      </div>`).join('')
    : '<div class="empty"><span class="empty-icon">📦</span>Add your first product<br>पहला सामान जोड़ें</div>';

  const opts = data.products.map(p =>
    `<option value="${p.id}">${p.name} (Stock: ${p.stock})</option>`
  ).join('');

  sellProduct.innerHTML = '<option value="">Select product / सामान चुनें</option>' + opts;
  buyProduct.innerHTML = '<option value="">Select product / सामान चुनें</option>' + opts;
}

function renderBills() {
  const list = document.getElementById('billList');
  list.innerHTML = data.bills.length
    ? data.bills.map(b => `
      <div class="list-item">
        <div class="item-avatar sell">🧾</div>
        <div class="info">
          <div class="title">${b.productName} × ${b.qty} @ ${fmt(b.rate)}</div>
          <div class="meta">${b.customer} · ${fmtDate(b.date)}</div>
        </div>
        <div class="right">
          <div class="amount income">${fmt(b.total)}</div>
          <button class="delete-btn" onclick="deleteBill('${b.id}')">Delete</button>
        </div>
      </div>`).join('')
    : '<div class="empty"><span class="empty-icon">🧾</span>No bills yet<br>अभी कोई बिल नहीं</div>';
}

function renderPurchases() {
  const list = document.getElementById('buyList');
  list.innerHTML = data.purchases.length
    ? data.purchases.map(p => `
      <div class="list-item">
        <div class="item-avatar buy">🛒</div>
        <div class="info">
          <div class="title">${p.productName} × ${p.qty} @ ${fmt(p.rate)}</div>
          <div class="meta">${fmtDate(p.date)}</div>
        </div>
        <div class="right">
          <div class="amount expense">${fmt(p.total)}</div>
          <button class="delete-btn" onclick="deletePurchase('${p.id}')">Delete</button>
        </div>
      </div>`).join('')
    : '<div class="empty"><span class="empty-icon">🛒</span>No purchases yet<br>अभी कोई खरीद नहीं</div>';
}

function renderMoney() {
  const entries = [
    ...data.income.map(i => ({ ...i, type: 'income' })),
    ...data.expenses.map(e => ({ ...e, type: 'expense' }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  const list = document.getElementById('moneyList');
  list.innerHTML = entries.length
    ? entries.map(e => `
      <div class="list-item">
        <div class="item-avatar ${e.type}">${e.type === 'income' ? '💰' : '💸'}</div>
        <div class="info">
          <div class="title">${e.note}</div>
          <div class="meta">${e.type === 'income' ? 'Income / आमदनी' : 'Expense / खर्च'} · ${fmtDate(e.date)}</div>
        </div>
        <div class="right">
          <div class="amount ${e.type}">${e.type === 'income' ? '+' : '−'}${fmt(e.amount)}</div>
          ${!e.ref ? `<button class="delete-btn" onclick="deleteMoney('${e.type}','${e.id}')">Delete</button>` : ''}
        </div>
      </div>`).join('')
    : '<div class="empty"><span class="empty-icon">💳</span>No entries yet<br>अभी कोई एंट्री नहीं</div>';
}

function renderAll() {
  renderDashboard();
  renderProducts();
  renderBills();
  renderPurchases();
  renderMoney();
}

renderAll();
